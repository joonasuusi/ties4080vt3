# A very simple Flask Hello World app for you to get started with...

from flask import Flask, render_template, session, url_for, redirect, request, Response
import mysql.connector.pooling
import mysql.connector
from functools import wraps
#import os
import hashlib
import json
from flask_wtf_polyglot import PolyglotForm
#tämä tuottaa xml-yhteensopivia lomakekenttiä
from wtforms import Form, PasswordField, StringField, validators, IntegerField, SelectField, widgets, SelectMultipleField, ValidationError, FieldList, FormField, BooleanField
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)

csrf = CSRFProtect(app)
csrf.init_app(app)
app.config.update(
    SESSION_COOKIE_SAMESITE='Lax'
)
app.secret_key = '"\xf9$T\x88\xefT8[\xf1\xc4Y-r@\t\xec!5d\xf9\xcc\xa2\xaa'

# avaa tietokannan yhteyden tiedot
f = open('/home/jopeuusi/vt3/dbconfig.json',)
dbconfig = json.load(f)

pool=mysql.connector.pooling.MySQLConnectionPool(pool_name="tietokantayhteydet",
pool_size=3, #PythonAnywheren ilmaisen tunnuksen maksimi on kolme
            **dbconfig
    )

# autentikointi funktio joukkueille
def auth(f):
    ''' Tämä decorator hoitaa kirjautumisen tarkistamisen ja ohjaa tarvittaessa kirjautumissivulle
    '''
    @wraps(f)
    def decorated(*args, **kwargs):
        # tässä voisi olla monimutkaisempiakin tarkistuksia mutta yleensä tämä riittää
        if not 'kirjautunut' in session:
            return redirect(url_for('kirjaudu'))
        return f(*args, **kwargs)
    return decorated

# autentikointi funktio admin sivuille
def auth2(f):
    ''' Tämä decorator hoitaa kirjautumisen tarkistamisen ja ohjaa tarvittaessa kirjautumissivulle
    '''
    @wraps(f)
    def decorated(*args, **kwargs):
        # tässä voisi olla monimutkaisempiakin tarkistuksia mutta yleensä tämä riittää
        if not 'kirjautunut_admin' in session:
            return redirect(url_for('admin'))
        return f(*args, **kwargs)
    return decorated

# Kirjautumissivu
@app.route('/', methods=['POST','GET'])
def kirjaudu():
    app.config['WTF_CSRF_ENABLED'] = False
    try:
        cnx = pool.get_connection()
        tunnus = request.form.get('tunnus', "")
        salasana = request.form.get('salasana', "")
        kilpailu = request.form.get("kili", "")
        m = hashlib.sha512()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''SELECT kisanimi
                FROM kilpailut
                '''

        cur.execute(sql)
        kilpailut = cur.fetchall()

        if len(tunnus) > 1 and len(kilpailu) > 1:
            cur = cnx.cursor(buffered=True, dictionary=True)
            sql = '''SELECT joukkueet.id, joukkueet.joukkuenimi, joukkueet.salasana, kilpailut.kisanimi, sarjat.kilpailu
                FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id
                JOIN kilpailut ON kilpailut.id = sarjat.kilpailu
                WHERE joukkueet.joukkuenimi = %s AND kilpailut.kisanimi = %s'''
            cur.execute(sql, (tunnus,kilpailu))
            joukkueet = cur.fetchall()

            session['tunnus'] = joukkueet[0]['joukkuenimi']
            session['kilpailu'] = kilpailu
            #session['joukkueid'] = joukkueet[0]['id']

            joukkue_id = str(joukkueet[0]['id'])
            m.update(joukkue_id.encode("UTF-8"))
            m.update(salasana.encode("UTF-8"))


            if tunnus.lower().strip()==joukkueet[0]['joukkuenimi'].lower().strip() and m.hexdigest() == joukkueet[0]['salasana']:
                session['kirjautunut'] = "OK"
                return redirect(url_for('vt3'))
            else:
                ilmoitus = "Kirjautuminen epäonnistui!"
                return render_template('kirjaudu.html', kilpailut=kilpailut)
        return render_template('kirjaudu.html', kilpailut=kilpailut)
    except:
        ilmoitus = "Kirjautuminen epäonnistui!"
        return render_template('kirjaudu.html', kilpailut=kilpailut, ilmoitus=ilmoitus)
    finally:
        cnx.close()

# Joukkuelistaussivu
@app.route('/vt3', methods=['POST','GET'])
@auth
def vt3():
    try:
        kilpailu = session['kilpailu']
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''SELECT sarjat.sarjanimi, joukkueet.joukkuenimi, joukkueet.jasenet, kilpailut.kisanimi
                FROM sarjat JOIN joukkueet ON sarjat.id = joukkueet.sarja
                JOIN kilpailut ON sarjat.kilpailu = kilpailut.id WHERE kilpailut.kisanimi = %s
                ORDER BY sarjanimi ASC, joukkuenimi ASC, jasenet ASC
                '''
        cur.execute(sql, (kilpailu,))
        tiedot = cur.fetchall()

        for i in range(len(tiedot)):
            tiedot[i]['jasenet'] = json.loads(tiedot[i]['jasenet'])

    except:
        pass
    finally:
        cnx.close()
    return render_template('vt3.html',joukkue=session['tunnus'], kilpailu=session['kilpailu'], tiedot=tiedot)

# Uloskirjautumissivu
@app.route('/vt3/logout')
def logout():
    session.pop('tunnus',None)
    session.pop('kilpailu',None)
    session.pop('kirjautunut',None)
    return redirect(url_for('kirjaudu'))

# Joukkueen tietojen muokkaussivu
@app.route('/vt3/muokkaa', methods=['POST','GET'])
@auth
def muokkaa():

    joukkueensarja = request.form.get("sarja")
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT joukkueet.id FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id JOIN kilpailut ON sarjat.kilpailu = kilpailut.id
                WHERE kilpailut.kisanimi = %s AND joukkueet.joukkuenimi = %s;
            '''
        cur.execute(sql, (session['kilpailu'],session['tunnus']))
        joukkue_id = cur.fetchall()
        joukkue_id = int(joukkue_id[0]['id'])
    except:
        pass
    finally:
        cnx.close()

    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT sarjat.id, sarjanimi FROM sarjat
                JOIN kilpailut ON sarjat.kilpailu = kilpailut.id AND kilpailut.kisanimi = %s
                ORDER BY sarjanimi ASC
              '''
        cur.execute(sql, (session['kilpailu'],))
        sarjat = cur.fetchall()
        select_sarjat = []
        for i in sarjat:
            select_sarjat.append((i['id'],i['sarjanimi']))
    except:
        pass
    finally:
        cnx.close()

    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
            SELECT joukkueet.jasenet FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id
            JOIN kilpailut ON sarjat.kilpailu = kilpailut.id WHERE kilpailut.kisanimi = %s
            AND joukkueet.joukkuenimi = %s
            '''
        cur.execute(sql, (session['kilpailu'],session['tunnus']))
        jasenet = cur.fetchall()
        jasenet[0]['jasenet'] = json.loads(jasenet[0]['jasenet'])
        k = len(jasenet[0]['jasenet'])
    except:
        pass
    finally:
        cnx.close()
    class joukkueentiedot(PolyglotForm):

        joukkuenimi = StringField('Joukkueen nimi', validators=[my_length_check], default=session['tunnus'])
        sarja = SelectField('Sarja', choices=select_sarjat)
        salasana = PasswordField('Salasana', validators=[my_length_check_salis])

        if k == 0:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check])
            jasen2 = StringField('Jäsen 2', validators=[my_length_check])
            jasen3 = StringField('Jäsen 3')
            jasen4 = StringField('Jäsen 4')
            jasen5 = StringField('Jäsen 5')
        if k == 1:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check], default=jasenet[0]['jasenet'][k-k])
            jasen2 = StringField('Jäsen 2', validators=[my_length_check])
            jasen3 = StringField('Jäsen 3')
            jasen4 = StringField('Jäsen 4')
            jasen5 = StringField('Jäsen 5')
        if k == 2:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check],default=jasenet[0]['jasenet'][k-k])
            jasen2 = StringField('Jäsen 2', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-1)])
            jasen3 = StringField('Jäsen 3')
            jasen4 = StringField('Jäsen 4')
            jasen5 = StringField('Jäsen 5')
        if k == 3:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check],default=jasenet[0]['jasenet'][k-k])
            jasen2 = StringField('Jäsen 2', validators=[my_length_check],default=jasenet[0]['jasenet'][k-(k-1)])
            jasen3 = StringField('Jäsen 3', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-2)])
            jasen4 = StringField('Jäsen 4')
            jasen5 = StringField('Jäsen 5')
        if k == 4:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check],default=jasenet[0]['jasenet'][k-k])
            jasen2 = StringField('Jäsen 2', validators=[my_length_check],default=jasenet[0]['jasenet'][k-(k-1)])
            jasen3 = StringField('Jäsen 3', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-2)])
            jasen4 = StringField('Jäsen 4', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-3)])
            jasen5 = StringField('Jäsen 5')
        if k == 5:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check], default=jasenet[0]['jasenet'][k-k])
            jasen2 = StringField('Jäsen 2', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-1)])
            jasen3 = StringField('Jäsen 3', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-2)])
            jasen4 = StringField('Jäsen 4', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-3)])
            jasen5 = StringField('Jäsen 5', validators=[my_length_check], default=jasenet[0]['jasenet'][k-(k-4)])

    form = joukkueentiedot()


    if request.method == 'POST':
        joukkuenimi = request.form.get("joukkuenimi")
        joukkueensarja = request.form.get("sarja")
        jasen1 = request.form.get("jasen1")
        jasen2 = request.form.get("jasen2")
        jasen3 = request.form.get("jasen3")
        jasen4 = request.form.get("jasen4")
        jasen5 = request.form.get("jasen5")
        salasana = request.form.get("salasana")

        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2))
        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0 and len(jasen3.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2,jasen3))
        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0 and len(jasen3.strip()) > 0 and len(jasen4.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2,jasen3,jasen4))
        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0 and len(jasen3.strip()) > 0 and len(jasen4.strip()) > 0 and len(jasen5.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2,jasen3,jasen4,jasen5))

        form.validate()
        # etsitään kilpailun joukkueet ja katsotaan onko saman nimistä
        totta = etsi_joukkue(joukkuenimi,joukkue_id)
        if len(joukkuenimi.strip()) > 0 and totta == True:
            try:
                cnx = pool.get_connection()
                cur = cnx.cursor(buffered=True, dictionary=True)
                if len(salasana.strip()) > 0:
                    m = hashlib.sha512()
                    m.update(str(joukkue_id).encode("UTF-8"))
                    m.update(salasana.encode("UTF-8"))
                    salis = m.hexdigest()
                    sql = '''
                        UPDATE joukkueet,sarjat,kilpailut SET joukkuenimi = %s, joukkueet.jasenet = %s, joukkueet.sarja = %s, joukkueet.salasana = %s
                            WHERE joukkueet.sarja = sarjat.id AND sarjat.kilpailu = kilpailut.id
                            AND kilpailut.kisanimi = %s AND joukkueet.id = %s;
                        '''
                    cur.execute(sql, (joukkuenimi, jasenet, joukkueensarja, salis, session['kilpailu'], joukkue_id))

                if len(salasana.strip()) < 1:
                    sql = '''
                        UPDATE joukkueet,sarjat,kilpailut SET joukkuenimi = %s, joukkueet.jasenet = %s, joukkueet.sarja = %s
                            WHERE joukkueet.sarja = sarjat.id AND sarjat.kilpailu = kilpailut.id
                            AND kilpailut.kisanimi = %s AND joukkueet.id = %s;
                        '''
                    cur.execute(sql, (joukkuenimi, jasenet, joukkueensarja, session['kilpailu'], joukkue_id))
                try:
                    cnx.commit()
                    session['tunnus'] = joukkuenimi
                except:
                    pass
                finally:
                    pass

            except:
                pass
            finally:
                cnx.close()

    return render_template('muokkaa.html', form=form, tunnus=session['tunnus'])

# etsitään kilpailun joukkueet ja katsotaan onko samannimistä
def etsi_joukkue(joukkue, j_id):
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
            SELECT joukkuenimi FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id JOIN kilpailut ON sarjat.kilpailu = kilpailut.id
            WHERE kilpailut.kisanimi = %s AND joukkueet.id != %s
            '''
        cur.execute(sql, (session['kilpailu'],j_id))
        joukkuenimet = cur.fetchall()
    except:
        pass
    finally:
        cnx.close()

    tottako = True
    for i in range(len(joukkuenimet)):
        if joukkuenimet[i]['joukkuenimi'].lower().strip() == joukkue.lower().strip():
            tottako = False

    return tottako


# tarkistaa syötettyjen jäsenten niumen pituuden onko validi
def my_length_check(form, field):
    if len(field.data.strip()) < 1:
        raise ValidationError('Liian lyhyt nimi')

# tarkistaa syötetyn salasanan pituuden onko validi
def my_length_check_salis(form, field):
    if len(field.data.strip()) < 1:
        raise ValidationError('Liian lyhyt salasana')


# Admin sivun kirjautuminen
@app.route('/admin', methods=['POST','GET'])
def admin():
    app.config['WTF_CSRF_ENABLED'] = False
    salasana = request.form.get('salasanakentta', "")
    m = hashlib.sha512()
    m.update(salasana.encode("UTF-8"))
    if m.hexdigest() == "c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec":
        session['kirjautunut_admin'] = "OK"
        return redirect(url_for('admin_page'))
    else:
        return render_template('admin.html')

# Sivu jolle saavutaan ensin kun kirjaudutaan adminina
@app.route('/admin_page', methods=['POST','GET'])
@auth2
def admin_page():
    return render_template('admin_page.html')

# sovelluksen etusivu adminina
@app.route('/etusivu')
@auth2
def frontpage():
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT kisanimi FROM kilpailut
              '''
        cur.execute(sql)
        kilpailut = cur.fetchall()
    except:
        pass
    finally:
        cnx.close()
    return render_template('etusivu.html', kilpailut=kilpailut)


# Uloskirjautumissivu adminille
@app.route('/admin_page/logout')
def logout_admin():
    session.pop('kirjautunut_admin',None)
    session.pop('sarja',None)
    session.pop('sarja_id',None)
    session.pop('kilpailu',None)
    session.pop('tunnus',None)
    return redirect(url_for('admin'))

# admin sivun killpailun valitsemissivu
@app.route('/etusivu/<kilpailu>')
@auth2
def sarjat(kilpailu):
    session['kilpailu'] = kilpailu
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT sarjat.id, sarjanimi FROM sarjat
                JOIN kilpailut ON sarjat.kilpailu = kilpailut.id AND kilpailut.kisanimi = %s
                ORDER BY sarjanimi ASC
              '''
        cur.execute(sql, (session['kilpailu'],))
        sarjat = cur.fetchall()
    except:
        pass
    finally:
        cnx.close()

    return render_template('sarjat.html', sarjat=sarjat, kili=session['kilpailu'])

# admin sivun sarjan valitsemissivu kun kilpailu on jo valittu
@app.route('/etusivu/<kilpailu>/<sarja>', methods=['POST','GET'])
@auth2
def joukkueet_sarjassa(kilpailu,sarja):
    session['sarja'] = sarja
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT sarjat.id FROM sarjat JOIN kilpailut ON sarjat.kilpailu = kilpailut.id
                WHERE sarjat.sarjanimi = %s AND kilpailut.kisanimi = %s
              '''
        cur.execute(sql, (session['sarja'], session['kilpailu']))
        sarja_id = cur.fetchall()
        session['sarja_id'] = sarja_id[0]['id']
    except:
        pass
    finally:
        cnx.close()

    joukkueet = []
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT joukkuenimi FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id JOIN kilpailut ON
                sarjat.kilpailu = kilpailut.id WHERE kilpailut.kisanimi = %s AND sarjat.sarjanimi = %s
              '''
        cur.execute(sql, (session['kilpailu'], session['sarja']))
        joukkueet = cur.fetchall()
    except:
        pass
    finally:
        cnx.close()
    class joukkueentiedot(PolyglotForm):
        joukkuenimi = StringField('Joukkueen nimi', validators=[my_length_check])
        jasen1 = StringField('Jäsen 1', validators=[my_length_check])
        jasen2 = StringField('Jäsen 2', validators=[my_length_check])
        jasen3 = StringField('Jäsen 3')
        jasen4 = StringField('Jäsen 4')
        jasen5 = StringField('Jäsen 5')
        salasana = PasswordField('Salasana', validators=[my_length_check_salis])

    form = joukkueentiedot()

    if request.method == 'POST':
        joukkuenimi = request.form.get("joukkuenimi")
        jasen1 = request.form.get("jasen1")
        jasen2 = request.form.get("jasen2")
        jasen3 = request.form.get("jasen3")
        jasen4 = request.form.get("jasen4")
        jasen5 = request.form.get("jasen5")
        salasana = request.form.get("salasana")

        taulu = [jasen1,jasen2,jasen3,jasen4,jasen5]
        taulu2 = []
        for i in range(len(taulu)):
            if taulu[i].strip() != "":
                taulu2.append(taulu[i])
            else:
                continue

        jasenet = json.dumps(taulu2)

        # etsitään suurin joukkueid jotta saadaan salasana tehtyä oikein tietokantaan
        #suurinID = etsi_id()
        #m = hashlib.sha512()
        #m.update(str(suurinID).encode("UTF-8"))
        #m.update(salasana.encode("UTF-8"))
        #salis = m.hexdigest()

        if request.method == 'POST' and form.validate():

            try:
                cnx = pool.get_connection()
                cur = cnx.cursor(buffered=True, dictionary=True)
                sql = '''
                    INSERT INTO joukkueet(joukkuenimi, salasana, sarja, jasenet) VALUES(%s, %s, %s, %s)
                  '''
                cur.execute(sql, (joukkuenimi, salasana, session['sarja_id'], jasenet))
                session['tunnus'] = joukkuenimi
                cnx.commit()
            except:
                pass
            finally:
                cnx.close()

            try:
                cnx = pool.get_connection()
                cur = cnx.cursor(buffered=True, dictionary=True)
                sql = '''
                    SELECT joukkueet.id FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id
                    JOIN kilpailut ON sarjat.kilpailu = kilpailut.id WHERE kilpailut.kisanimi = %s
                    AND joukkueet.joukkuenimi = %s
                    '''
                cur.execute(sql, (session['kilpailu'],joukkuenimi))
                tiedot = cur.fetchall()
                joukkue_id = tiedot[0]['id']
            except:
                pass
            finally:
                cnx.close()


            try:
                m = hashlib.sha512()
                m.update(str(joukkue_id).encode("UTF-8"))
                m.update(salasana.encode("UTF-8"))
                salis = m.hexdigest()
                cnx = pool.get_connection()
                cur = cnx.cursor(buffered=True, dictionary=True)
                sql = '''
                    UPDATE joukkueet,sarjat,kilpailut SET joukkueet.salasana = %s
                            WHERE joukkueet.sarja = sarjat.id AND sarjat.kilpailu = kilpailut.id
                            AND kilpailut.kisanimi = %s AND joukkueet.id = %s;
                  '''
                cur.execute(sql, (salis, session['kilpailu'], joukkue_id))
                cnx.commit()
            except:
                pass
            finally:
                cnx.close()

            try:
                cnx = pool.get_connection()
                cur = cnx.cursor(buffered=True, dictionary=True)
                sql = '''
                        SELECT joukkuenimi FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id JOIN kilpailut ON
                        sarjat.kilpailu = kilpailut.id WHERE kilpailut.kisanimi = %s AND sarjat.sarjanimi = %s
                      '''
                cur.execute(sql, (session['kilpailu'], session['sarja']))
                joukkueet = cur.fetchall()
            except:
                pass
            finally:
                cnx.close()



    return render_template('listaus.html',sarjis=session['sarja'],kili=session['kilpailu'],form=form,joukkueet=joukkueet)


# etsii suurimman joukkue idn ja lisää siihen +1
def etsi_id():
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
            SELECT id FROM joukkueet
          '''
        cur.execute(sql)
        idt = cur.fetchall()
    except:
        pass
    finally:
        cnx.close()

    suurin = 0
    for i in range(len(idt)):
        if idt[i]['id'] > suurin:
            suurin = idt[i]['id']

    return suurin+1

# sivu joukkueen tietojen muokkaukseen admin sivulta
@app.route('/etusivu/<kilpailu>/<sarja>/<tunnus>', methods=['POST','GET'])
@auth2
def muokkaa_admin_sivulta(kilpailu,sarja,tunnus):
    session['tunnus'] = tunnus

    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
            SELECT joukkueet.jasenet,joukkueet.id FROM joukkueet JOIN sarjat ON joukkueet.sarja = sarjat.id
            JOIN kilpailut ON sarjat.kilpailu = kilpailut.id WHERE kilpailut.kisanimi = %s
            AND joukkueet.joukkuenimi = %s
            '''
        cur.execute(sql, (session['kilpailu'],session['tunnus']))
        tiedot = cur.fetchall()
        tiedot[0]['jasenet'] = json.loads(tiedot[0]['jasenet'])
        joukkue_id = tiedot[0]['id']
        k = len(tiedot[0]['jasenet'])
    except:
        pass
    finally:
        cnx.close()

    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT sarjat.id, sarjanimi FROM sarjat
                JOIN kilpailut ON sarjat.kilpailu = kilpailut.id AND kilpailut.kisanimi = %s
                ORDER BY sarjanimi ASC
              '''
        cur.execute(sql, (session['kilpailu'],))
        sarjat = cur.fetchall()
        select_sarjat = []
        for i in sarjat:
            select_sarjat.append((i['id'],i['sarjanimi']))
    except:
        pass
    finally:
        cnx.close()

    class joukkueentiedot(PolyglotForm):
        poistajoukkue = BooleanField('Poista joukkue')
        joukkuenimi = StringField('Joukkueen nimi', validators=[my_length_check], default=tunnus)
        salasana = PasswordField('Salasana', validators=[my_length_check_salis])
        sarja = SelectField('Sarja', choices=select_sarjat)
        try:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check],default=tiedot[0]['jasenet'][0])
        except:
            jasen1 = StringField('Jäsen 1', validators=[my_length_check],default="")
        try:
            jasen2 = StringField('Jäsen 2', validators=[my_length_check],default=tiedot[0]['jasenet'][1])
        except:
            jasen2 = StringField('Jäsen 2', validators=[my_length_check],default="")
        try:
            jasen3 = StringField('Jäsen 3',default=tiedot[0]['jasenet'][2])
        except:
            jasen3 = StringField('Jäsen 3',default="")
        try:
            jasen4 = StringField('Jäsen 4',default=tiedot[0]['jasenet'][3])
        except:
            jasen4 = StringField('Jäsen 4',default="")
        try:
            jasen5 = StringField('Jäsen 5',default=tiedot[0]['jasenet'][4])
        except:
            jasen5 = StringField('Jäsen 5',default="")

    form = joukkueentiedot()

    if request.method == 'POST':
        poistajoukkue = request.form.get("poistajoukkue")
        joukkuenimi = request.form.get("joukkuenimi")
        joukkueensarja = request.form.get("sarja")
        jasen1 = request.form.get("jasen1")
        jasen2 = request.form.get("jasen2")
        jasen3 = request.form.get("jasen3")
        jasen4 = request.form.get("jasen4")
        jasen5 = request.form.get("jasen5")
        salasana = request.form.get("salasana")

        if poistajoukkue == "y":
            try:
                cnx = pool.get_connection()
                cur = cnx.cursor(buffered=True, dictionary=True)
                sql = '''
                        SELECT rasti FROM tupa JOIN joukkueet ON tupa.joukkue = joukkueet.id WHERE joukkueet.id = %s
                      '''
                cur.execute(sql, (joukkue_id,))
                rastit = cur.fetchall()
            except:
                pass
            finally:
                cnx.close()

            if len(rastit) > 0:
                viesti = "Joukkuetta ei voi poistaa, rastileimauksien vuoksi"
                return render_template('muokkaa_admin_sivulta.html', form=form, viesti=viesti)
            else:
                try:
                    cnx = pool.get_connection()
                    cur = cnx.cursor(buffered=True, dictionary=True)
                    sql = '''
                            DELETE FROM joukkueet WHERE joukkueet.id = %s
                          '''
                    cur.execute(sql, (joukkue_id,))
                    cnx.commit()
                except:
                    pass
                finally:
                    cnx.close()
                    return redirect(url_for('frontpage'))

        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2))
        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0 and len(jasen3.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2,jasen3))
        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0 and len(jasen3.strip()) > 0 and len(jasen4.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2,jasen3,jasen4))
        if len(jasen1.strip()) > 0 and len(jasen2.strip()) > 0 and len(jasen3.strip()) > 0 and len(jasen4.strip()) > 0 and len(jasen5.strip()) > 0:
            jasenet = json.dumps((jasen1,jasen2,jasen3,jasen4,jasen5))

        form.validate()
        totta = etsi_joukkue(joukkuenimi,joukkue_id)
        if len(joukkuenimi.strip()) > 0 and totta == True:
            try:
                cnx = pool.get_connection()
                cur = cnx.cursor(buffered=True, dictionary=True)
                if len(salasana.strip()) > 0:
                    m = hashlib.sha512()
                    m.update(str(joukkue_id).encode("UTF-8"))
                    m.update(salasana.encode("UTF-8"))
                    salis = m.hexdigest()
                    sql = '''
                        UPDATE joukkueet,sarjat,kilpailut SET joukkuenimi = %s, joukkueet.jasenet = %s, joukkueet.sarja = %s, joukkueet.salasana = %s
                            WHERE joukkueet.sarja = sarjat.id AND sarjat.kilpailu = kilpailut.id
                            AND kilpailut.kisanimi = %s AND joukkueet.id = %s;
                        '''
                    cur.execute(sql, (joukkuenimi, jasenet, joukkueensarja, salis, session['kilpailu'], joukkue_id))

                if len(salasana.strip()) < 1:
                    sql = '''
                        UPDATE joukkueet,sarjat,kilpailut SET joukkuenimi = %s, joukkueet.jasenet = %s, joukkueet.sarja = %s
                            WHERE joukkueet.sarja = sarjat.id AND sarjat.kilpailu = kilpailut.id
                            AND kilpailut.kisanimi = %s AND joukkueet.id = %s;
                        '''
                    cur.execute(sql, (joukkuenimi, jasenet, joukkueensarja, session['kilpailu'], joukkue_id))

                try:
                    cnx.commit()
                    session['tunnus'] = joukkuenimi
                except:
                    pass
                finally:
                    pass

            except:
                pass
            finally:
                cnx.close()

    return render_template('muokkaa_admin_sivulta.html',form=form)


@app.route('/etusivu/kilpailut', methods=['POST','GET'])
@auth2
def kilpailut_sivu():
    try:
        cnx = pool.get_connection()
        cur = cnx.cursor(buffered=True, dictionary=True)
        sql = '''
                SELECT kisanimi FROM kilpailut
              '''
        cur.execute(sql)
        kilpailut = cur.fetchall()
    except:
        pass
    finally:
        cnx.close()
    return render_template('kilpailut.html', kilpailut=kilpailut)


@app.route('/etusivu/sarjat', methods=['POST','GET'])
@auth2
def sarjat_sivu():
    if session.get('kilpailu') == "":
        return redirect(url_for('kilpailut_sivu'))
    if session.get('kilpailu') != session['kilpailu']:
        session.pop('sarja',None)
        session.pop('sarja_id',None)
        session.pop('tunnus',None)
        try:
            cnx = pool.get_connection()
            cur = cnx.cursor(buffered=True, dictionary=True)
            sql = '''
                    SELECT sarjat.id, sarjanimi FROM sarjat
                    JOIN kilpailut ON sarjat.kilpailu = kilpailut.id AND kilpailut.kisanimi = %s
                    ORDER BY sarjanimi ASC
                  '''
            cur.execute(sql, (session['kilpailu'],))
            sarjat = cur.fetchall()
        except:
            pass
        finally:
            cnx.close()


        return render_template('sarjat_sivu.html', sarjat=sarjat)
    else:
        try:
            cnx = pool.get_connection()
            cur = cnx.cursor(buffered=True, dictionary=True)
            sql = '''
                    SELECT sarjat.id, sarjanimi FROM sarjat
                    JOIN kilpailut ON sarjat.kilpailu = kilpailut.id AND kilpailut.kisanimi = %s
                    ORDER BY sarjanimi ASC
                  '''
            cur.execute(sql, (session['kilpailu'],))
            sarjat = cur.fetchall()
        except:
            pass
        finally:
            cnx.close()


        return render_template('sarjat_sivu.html', sarjat=sarjat)















